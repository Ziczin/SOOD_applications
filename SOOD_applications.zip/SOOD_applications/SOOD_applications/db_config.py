

params = {
    'default': {
        'ENGINE': 'mssql',
        'NAME': 'Applications_Django_Python',
        'USER': 'Applications_Django_Python',
        'PASSWORD': '00000000',
        'HOST': 'server-sql',
        'PORT': '1433',
        'OPTIONS': {
            'driver': 'ODBC Driver 17 for SQL Server',
            'autocommit': True,
            'timeout': 300,
        },
    }
}