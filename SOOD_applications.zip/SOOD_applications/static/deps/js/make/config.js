export default {
    generateTestIds: true
}