export default (withCss) => {
    let base = `make-`
    let text = base + `text-`
    let btn = base + `btn-`
    let gap = base + `gap-`
    let card = base + `card-`
    let action = base + `btn-action-`
    
    return {
        goose: withCss(base + `goose`),

        popup: withCss(base + `popup`),
        content: withCss(base + `content`),
        contented: withCss(base + `contented`),
        noticeBody: withCss(base + `notice-body`),

        textItalic: withCss(text + `italic`),
        textBold: withCss(text + `bold`),

        centered: withCss(base + `it-centered`),
        textCentered: withCss(text + `centered`),
        leftAlign: withCss(base + `text-align-left`),

        subtitleText: withCss(text + `subtitle`),
        simpleLink: withCss(base + `simple-link`),

        cardHeader: withCss(card + `header-additional`),
        cardContent: withCss(card + `content-additional`),

        littleDarker: withCss(base + `little-darker`),
        littleLighter: withCss(base + `little-lighter`),

        flex: withCss(base + `flex`),
        flexRow: withCss(base + `flex-row`),
        flexColumn: withCss(base + `flex-column`),
        gap6px: withCss(gap + `6px`),
        gap10px: withCss(gap + `10px`),

        formGroup: withCss(base + `form-group`),
        delayedMarginOnHover: withCss(base + `delayed-margin-on-hover`),
        marginOnHover: withCss(base + `margin-on-hover`),

        card: withCss(`card`),
        body: withCss(`card-body`),

        warning: withCss(`btn`, `btn-warning`, `btn-sm`),
        danger: withCss(`btn`, `btn-danger`, `btn-sm`),
        link: withCss(`btn`, `btn-link`),
        primary: withCss(`btn`, `btn-primary`),
        redir: withCss(base + `btn-redir`),
        onConfirmationMargin: withCss(base + `confirmation-margin`),
        
        shadeAtBorder: withCss(base + `shade-at-border`),
        squared: withCss(base + `squared`),
        action: withCss(base + `btn-action`),
        imageAction: withCss(base + `img-btn`),
        act: {
            positive: withCss(action + `positive`),
            negative: withCss(action + `negative`),
            neutral: withCss(action + `neutral`),
            alternative: withCss(action + `alternative`),
        }
    }
}