export default (withCss) =>
{
    let prefix = `make-color-`
    return {
        error: withCss(prefix + `error`),
        lred: withCss(prefix + `l-red`),
        red: withCss(prefix + `red`),
        dred: withCss(prefix + `d-red`),
        blue: withCss(prefix + `blue`),
        lblue: withCss(prefix + `l-blue`),
        yellow: withCss(prefix + `yellow`),
        lyellow: withCss(prefix + `l-yellow`),
        green: withCss(prefix + `green`),
        lgreen: withCss(prefix + `l-green`),
        lgray: withCss(prefix + `l-gray`),
        sgray: withCss(prefix + `s-gray`),
        mgray: withCss(prefix + `m-gray`),
        dgray: withCss(prefix + `d-gray`),
        vgray: withCss(prefix + `v-gray`),
        white: withCss(prefix + `white`),
    }
}
