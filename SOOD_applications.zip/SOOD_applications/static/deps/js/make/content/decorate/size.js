export default (withCss) =>
{
    let prefix = `make-size-`
    return {
        small: withCss(prefix + `small`),
        medium: withCss(prefix + `medium`),
        large: withCss(prefix + `large`),
    }
}
