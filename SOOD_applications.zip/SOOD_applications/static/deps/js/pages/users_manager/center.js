export default async () =>
{
  await import(`${window.make_url}/make.js`);
  const imp = (await import(`${window.prefab_url}/import.js`)).default(make)
  const paragraphNotice = await imp(`${window.prefab_url}/paragraph_notice.js`)
  const actionNotice = await imp(`${window.prefab_url}/action_notice.js`)
  const popup = await imp(`${window.prefab_url}/popup.js`)
  const picButton = await imp(`${window.prefab_url}/pic_button.js`, popup, window.media_url);

  const csrfObj = await make.Query('/api/csrf-token').get()
  const qBase = make.Query('/api').via({"X-CSRFToken": csrfObj.csrfToken}).view();
  const qUsers = qBase.at('users').view();
  const qRoles = qBase.at('roles').view()

  const me = await qBase.at('me').get()
  const roles = await qRoles.get()

  document.getElementById('center-content').appendChild(
    make.Div(
      make.it.flexColumn,
      make.style.gap(6),
      make.h1(me.department.name),
      make.Scrollbox(
        make.it.flexColumn,
        make.style.gap(6),
        ...(await qUsers.where({department: me.department.id}).get()).map((u) =>
          userElem(u, qUsers, me)
        )
      )
    ).build()
  )

  function userElem(user, makeQuery, me) {
    let acc;
    let out = make.Div(make.it.marginOnHover)
    let inp
    let verifyBtn
    inp = make.Input(
      make.with.attr({
        value: user.fullname || "",
        placeholder: user.fullname || "Безымянный пользователь"
      }),
      make.on.input((e) =>
        out.element.classList.add("make-mark-changed")
      ),
      make.on.inputTimeOut(3000, () => {
        out.element.classList.remove("make-mark-changed")
        qUsers.at(user.id).with({fullname: inp.element.value || ''}).patch()
        paragraphNotice("Сохранено!", make.color.lgreen)
      }),
      ...make.if(user.id === me.id,
        make.Annotation(1500, 
          make.Div(
            make.it.popup,
            make.Paragraph("Нажмите на поле ввода для редактирования"),
            make.Paragraph("Если элемент подсвечен, то он сохранится через некоторое время"),
            make.Paragraph("Если вы перейдёте на другой элемент, то этот так же сохранится автоматически"),
            make.Paragraph("Вы не можете редактировать свою роль", make.it.textBold),
          )
        )
      ),
      ...make.if(user.id !== me.id,
        make.Annotation(1500, 
          make.Div(
            make.it.popup,
            make.Paragraph("Нажмите на поле ввода для редактирования"),
            make.Paragraph("Если элемент подсвечен, то он сохранится через некоторое время"),
            make.Paragraph("Если вы перейдёте на другой элемент, то этот так же сохранится автоматически"),
          )
        )
      ),

    )
    acc = make.Div(
      make.with.css("make-mark-filtered"),
      make.it.flexRow,
      make.style.gap(6),
      inp,
      ...make.if(!user.verified,
        verifyBtn = picButton("verify", "Верифицировать пользователя", make.it.act.positive,
          () => actionNotice({
            confirmText: "Верифицировать", cancelText: "Отмена",
            question: `Верифицировать ${inp.element.value || "*безымянный пользователь*"}?`,
            action: () => {
              acc.removeChild(verifyBtn)
              makeQuery.at(user.id).with({verified: true}).patch()
              paragraphNotice("Пользователь верифицирован!", make.color.yellow)
            }
          })
        )
      ),
      ...make.if(user.id !== me.id,
        make.Select(
          make.Annotation(1500, 
            make.Div(
              make.it.popup,
              make.Paragraph("Нажмите чтобы выбрать роль пользователя"),
            )
          ),
          make.with.style({maxWidth: "max-content"}),
          ...roles.map(role => 
            make.Option(
              role.name, role.id,
              ...make.if(role.id === user.role.id,
                make.with.attrs('selected')
              )
            )
          ),
          make.on.change(async (e) => {
            qUsers.at(user.id).at('change_role').with({role: e.target.value}).patch()
          })
        )
      )
    )
    out.addChild(acc)
    return out
  }
}

