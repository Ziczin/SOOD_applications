export default async () =>
{
  
  await import(`${window.make_url}/make.js`);
  const imp = (await import(`${window.prefab_url}/import.js`)).default(make)
  const csrfObj = await make.Query('/api/csrf-token').get()

  const qBase = make.Query('/api').via({"X-CSRFToken": csrfObj.csrfToken}).view();
  const qLogout = qBase.at('auth/logout').view()
  const qCurrentUser = qBase.at('me').view();
  const me = await qCurrentUser.get();

  const popup = await imp(`${window.prefab_url}/popup.js`)
  const picButton = await imp(`${window.prefab_url}/pic_button.js`, popup, window.media_url);
  const basicManual = await imp(`${window.manual_url}/basic_manual.js`, popup, picButton);
  const mainManual = await imp(`${window.manual_url}/main_manual.js`, me.permissions, qBase)

  document.getElementById('manual-button').appendChild(basicManual(mainManual).build())

  document.getElementById('logout-btn').appendChild(
    make.Button(
      make.with.css('content', 'exit', 'flex'),
      make.with.text('Сменить аккаунт'),
      make.on.click(async () => {
        await qLogout.post()
        window.location.href = ''
      })
    ).build()
  )

  document.getElementById('left-content').appendChild(
    make.Div(
      make.it.flexColumn,
      make.it.gap6px,
      make.style.height("100%"),
      make.h1(`${me.fullname}`),
      make.Paragraph(`@${me.username}`, make.it.subtitleText),
      make.Paragraph(me.role.name,
        ...make.if(me.permissions.includes('proxy'),
          make.with.style({
            textDecorationLine: 'line-through',
            textDecorationColor: 'rgba(0,0,0,0.35)',
            fontStyle: "italic"
          })
        )),
      make.Paragraph(me.department?.name ? me.department.name : 'Без отдела',
        ...make.if(me.permissions.includes('proxy'),
          make.with.style({
            textDecorationLine: 'line-through',
            textDecorationColor: 'rgba(0,0,0,0.35)',
            fontStyle: "italic"
          })
        )
      ),
      ...make.if(me.permissions.includes('proxy'),
        make.Paragraph(
          "Вы - ",
          make.with.style({
            color: "magenta",
          }),
          make.Span('прокси',
            make.on.click(
              createNoiseCycler(2000, 1000, [
				"суперюзер", "агент", "знание", "a͢b̨a͢͟͠d̶o̕͝͞n͢͏n̨͝҉e̢͏d", 
				"p̴̡͞r͟o̵x̨̡͠y̨͢͡", "</>", "dev", 
				"ℵ", "прокси", "мимик", "???", 
				"призрак", "ордо", "кто?", "образ", 
				"me.username", "наблюдатель", "me.role.name", "тень", 
				"...", "42", "герой", "(()=>{})()", 
				"лямбда", "виртуальный", "π", "α", 
				"ξ", "Ω", "null", "undefined", 
				"система", "интерфейс", "пространство",
				"гибрид", "404", "протокол", 
				"поток", "модуль", "шаблон", "сигнал", 
				"мир", "сущность", "система", "вход", "выход",
				"реальность", "алгоритм", "идентичность",
				"потенциал", "состояние", "парадигма", "переменная",
				"мышление", "принятие", "особенность", "реакция",
				"проблема", "контекст", "изменение", "метод",
				"структура", "ценность", "восприятие", "установка",
				"измерение", "дихотомия", "оптимизация", "аспект",
				"правило", "подход", "феномен", 
              ])
            )
          )
        )
      ),
    ).build()
  );

  function createNoiseCycler(animDuration = 1000, displayDuration = 1000, list = []) {
    const noiseChars = '¢£€₽₹₺₫₱₪₦₴₲₼₡₭!?#%' +
                      'йцукенгшщзхъфывапролджэячсмитьбюё' +
                      'abcdefghijklmnopqrstuvwxyz' +
                      'αβγδεζηικλμνξοπρστυφχψωϑϰϕϱϖ' + 
                      'אבגדהוזחטיכלמנסעפצקרשתװױײ' +
                      'աբգդեզըթժիմխձՃգհճմյնշոչպջռսվտրձւփքօֆ' +
                      'αβγδεζηθικλμνξοπρστυφχψω'
    const k = 10;
    const totalTicks = Math.max(0, Math.floor(animDuration / k));
    const randInt = n => Math.floor(Math.random() * n);
    const randIdx = () => randInt(list.length)
    const randNoise = () => noiseChars.charAt(randInt(noiseChars.length));
    const sleep = ms => new Promise(res => setTimeout(res, ms));
    var active = false;

    return async function handlePointerEvent(event, startIndex = 0) {
      if (active) return
      active = true
      const el = event.currentTarget;
      let prev = []
      while (true) {
        let idx = randIdx()
        while (prev.includes(idx)){
          idx = randIdx()
        }
        prev.push(idx)
        prev = prev.slice(-16)
        const target = String(list[idx]);
        const len = target.length;
        const noiseTicks = Math.max(0, totalTicks - len);
        const repairTicks = totalTicks - noiseTicks;

        const work = Array.from(target);
        let displayed = Array.from(el.textContent || '');

        const diff = displayed.length - len;
        const remaining = Math.abs(diff);
        const step = remaining > 0 ? Math.max(1, Math.floor(noiseTicks / remaining)) : Infinity;

        for (let t=0; t < noiseTicks; t++) {
          if (remaining > 0 && (t % step) === 0) {
            if (diff < 0) {
              const insertPos = randInt(displayed.length + 1);
              displayed.splice(insertPos, 0, randNoise());
            } else if (diff > 0) {
              const removePos = randInt(displayed.length);
              displayed.splice(removePos, 1);
            }
          } else {
            if (displayed.length > 0) {
              displayed[randInt(displayed.length)] = randNoise();
            } else {
              displayed.push(randNoise());
            }
          }
          el.textContent = displayed.join('');
          await sleep(k);
        }
        if (displayed.length > len) displayed.length = len;

        for (let t=0; t < repairTicks; t++) {
          const wrong = [];
          for (let k = 0; k < len; k++) {
            if (displayed[k] !== work[k]) wrong.push(k);
          }
          if (wrong.length > 0) {
            const pick = wrong[randInt(wrong.length)];
            displayed[pick] = work[pick];
            el.textContent = displayed.join('');
          }
          await sleep(k);
        }

        await sleep(displayDuration);
      }
    };
  }
}