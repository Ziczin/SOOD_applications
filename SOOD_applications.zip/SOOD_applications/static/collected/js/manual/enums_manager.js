export default(e=>function(){e.Tabs(e.style.height("100%")).menu(e.it.flexRow,e.it.gap10px,e.style.rounded(12),e.style.padding(8))});
