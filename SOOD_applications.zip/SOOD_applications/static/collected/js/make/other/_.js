import o from"./getCookie.js";import t from"./conditions.js";export default{getCookie:o,conditions:t};
