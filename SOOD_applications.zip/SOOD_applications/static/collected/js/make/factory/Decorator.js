export default(e=>function(n,t=!1){return(...r)=>new e(e=>n(e,...r),t)});
