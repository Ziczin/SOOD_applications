import o from"./Component.js";import r from"./Decorator.js";import t from"./Handler.js";export default{Component:o,Decorator:r,Handler:t};
