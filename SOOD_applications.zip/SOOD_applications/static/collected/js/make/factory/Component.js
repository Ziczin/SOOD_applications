export default(e=>function(r,...t){let a;if(Array.isArray(r)){let[t,i]=r;(a=new e(t,!1)).name=i}else a=new e(r,!1);return a.addModifiers(...t).autoRebuild=!0,a});
