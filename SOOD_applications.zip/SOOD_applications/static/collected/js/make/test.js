import e from"./test/_.js";import r from"./extension/_.js";e.all("Preferences",e.preferences(r.Preferences(r.Flag),r.Flag),!0);
