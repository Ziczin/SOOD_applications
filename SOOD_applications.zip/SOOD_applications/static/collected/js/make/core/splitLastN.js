export default((e=[],t=1)=>{if(t<=0)return[e.slice(),[]];let l=Math.min(t,e.length),i=e.length-l;return[e.slice(0,i),e.slice(i)]});
