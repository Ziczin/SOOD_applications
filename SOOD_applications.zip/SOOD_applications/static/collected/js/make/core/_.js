import m from"./delay.js";import o from"./mix.js";export default{delay:m,mix:o};
