export default async function e(e){return new Promise(t=>setTimeout(t,e))}
