import r from"./decorate/_.js";import o from"./prefab/_.js";export default{decorate:r,prefab:o};
