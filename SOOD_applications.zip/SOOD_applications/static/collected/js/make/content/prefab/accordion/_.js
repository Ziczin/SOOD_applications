import o from"./Card.js";import r from"./Accordion.js";export default{Card:o,Accordion:r};
