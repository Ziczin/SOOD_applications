export default(e=>{let l="make-size-";return{small:e(l+"small"),medium:e(l+"medium"),large:e(l+"large")}});
