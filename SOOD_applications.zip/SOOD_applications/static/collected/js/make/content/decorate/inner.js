import"./with.js";export default(o=>({separator:o("make-block-separator"),scrollbox:o("make-scrollbox")}));
