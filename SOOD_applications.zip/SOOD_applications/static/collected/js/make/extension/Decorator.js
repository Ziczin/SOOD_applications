class p{apply(p){(this.needReApply||!this.applied)&&(this.func(p),this.applied=!0)}constructor(p,e=!0){this.func=p,this.needReApply=e,this.applied=!1}}export{p as default};
