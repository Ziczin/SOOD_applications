export default(t=>function(a,r,e=500,i=!0){return Array.isArray(a)||(a=[a]),t.Notice([500,e,500,a,{weak:i}],t.Div(t.it.content,t.it.flexColumn,t.style.gap(6),r,...a.map(a=>t.Paragraph(a))))});
