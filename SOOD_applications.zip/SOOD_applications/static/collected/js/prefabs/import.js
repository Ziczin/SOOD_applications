export default(t=>async function(a,...e){return(await import(a)).default(t,...e)});
